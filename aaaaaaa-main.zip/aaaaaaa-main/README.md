# UV-Static-2.0
UV-Static... But WISP and Tabbed!

This is a succesor to [UV-Static](https://github.com/rhenryw/UV-Static)

This uses WISP technology

How to use:
---
1. Copy `/active` to root dir (`/`) of site

2. Done! You will be able to  access the proxy at `/active`. If you change the location of the folder or change the name of the folder you will also have to modify `active/uv/uv.config.js` and `active/scripts/prxy.mjs`. You can change the styles and app at will!


Disclaimer
---
UV is made by [titaniumnetwork](https://github.com/titaniumnetwork-dev/Ultraviolet), and we have no part in developing it. The backend was made by [Mercury Network](https://mercurywork.shop/).


Backend: [deployWISP](https://github.com/rhenryw/deployWisp)
